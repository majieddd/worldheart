# Source retrospective of frozen blind observations

Read-only retrospective completed 2026-09-05, after blind freeze. Repository commit verified as1374122d1109919a5fab10b69fefdfb80308eb6e at C:/Users/Majied LaFleur/Documents/GPTProjects/worldheart. Read CONTRIBUTING.md and CLAUDE.md first. Examined only the requested main/camera/ui/mode/draft source files. No edits to repository or frozen notes, no browser actions, no runtime tests. Source examination explains candidate mechanisms; it is not additional runtime proof.

## Corrections that matter for the final report

1. **Retract “confirmed cap arithmetic/off-by-one bug.”** The panel intentionally previews the NEXT purchase, while the tower and toast display the CURRENT cap. The blind confusion is real and reproducible, but it is ambiguous product copy rather than evidence the cap calculation is wrong.
2. **Retract the hypothesis that pause freezes the orbit camera.** Source updates the camera regardless of game.paused. R resets view rotation only, not camera position or zoom. The failed attempt to use R to return to the core was a mistaken expectation prompted by terse instructions.
3. **Do not claim draft timers continue during pause.** They explicitly stop while paused. A vote clicked during pause is stored but resolution waits for a later run tick, which explains the apparently stuck selected card.
4. **Do not call zero Warden Dealt/Kills proof it was ineffective.** The inspected UI prints tower-owned counters even for summoners; attribution from soldiers needs a separate combat-system audit.

## 1. Heart panel: next-purchase preview is insufficiently labelled

Evidence:
- js/modes/ninetynine.js:122 assigns actual game.tierCap=run.getTierCap().
- js/modes/ninetynine.js:129 passes tierCap=current and :130 nextTierCap=current+1 to the UI.
- js/ui.js:644-647 documents that the panel describes the next purchase and what it buys.
- js/ui.js:660 prints “tier cap” using **info.nextTierCap** whenever another purchase exists. At maximum level, :653 instead prints current info.tierCap.
- js/ui.js:909 labels tower t.tier+1; :937 caps upgrade when t.tier+1>=game.tierCap.
- js/modes/ninetynine.js:194 toast uses actual run.getTierCap().

Conclusion: the observed LV0/MKIII versus capped MKII is the purchase preview for250gold. LV1/MK4 is the next450gold purchase, while the new current cap isMKIII. There is no evidence here of model/view cap calculation divergence. Better copy: show “Current cap MKII” and “Upgrade: cap MKIII, +2rings” as distinct values. Severity fits usability/planning confusion, not game-rule corruption. The frozen record retains the original blind interpretation to preserve provenance.

Missing verification: current and next cap at every Heart level, max-level panel, purchasing while a tower panel is open, keyboard/button consistency, actual cap enforcement. A UI regression should assert both current and next values are unambiguously labelled. No such tests were run in this retrospective.

## 2. Camera: pause hypothesis disproven; several authored travel paths exist

Evidence:
- js/main.js:575-577 computes simRunning separately and calls rig.update(dt) whenever not possessed, without a pause guard.
- js/camera.js:668-694 advances keyboard input, flights, inertia and zoom smoothing on each update.
- js/camera.js:214-225 maps R to resetView(), which only sets viewYaw=0 and tiltOffset=0. It does not change lon/lat/dist or cancel a flight.
- js/ui.js:180 places “R resets” after view rotation instructions. It never promises return-to-heart explicitly; my blind interpretation was too broad.
- js/ui.js:542-547 starts a1.6s flyTo toward heart when Begin is clicked.
- js/main.js:339-343 unconditionally flies toward a newly waking portal for1.1s, with “A new breach tears open” toast.
- js/modes/ninetynine.js:488-494 flies toward heart for0.35s on possession exit. This directly explains why Escape suddenly gave us a helpful core overview.
- js/modes/ninetynine.js:48-49 changes frontier-dependent zoom/confinement bounds; js/camera.js:281-293 computes maximum zoom from frontier size. This can change framing constraints, but does not by itself prove our perceived pan.
- js/ui.js:546 sets autoOrbit=0 when gameplay begins. Do not blame normal title auto-orbit for ongoing gameplay movement.

Conclusion: paused camera freeze is unsupported and contradicted by code. Initial delayed zoom perception may reflect frame/transport delay or a still-running introductory flight. During later play, portal-wake camera flights are a credible intended source of unexpected travel; **the blind trace did not timestamp each camera move against each portal event**, so do not attribute every movement conclusively. No edge-panning mechanism was identified in these files; the blind edge-pan hypothesis remains unsupported. The authored flyTo at portal wake can wrest attention from a defensive task, which deserves a controlled usability test.

Missing verification: native continuous-input paused zoom/rotation/pan; R rotation behavior and a separate return-to-core affordance; portal wake while inspecting/upgrading a tower; whether player input cancels pending flight; exact frame/AX timestamp correlation; camTest across allfive maps per repository instructions. No runtime camera tests were run here.

## 3. Draft: ten raw-dt seconds, seeded fallback, paused vote awaiting tick

Evidence:
- js/run/draft.js:14 sets DRAFT_SECONDS=10; :16-24 initializes remaining and empty votes.
- js/run/draft.js:27-33 castVote only stores the index, does not resolve the draft.
- js/run/draft.js:66-75 tickDraft resolves everyone-voted first, otherwise subtractsdt and resolves timeout atzero.
- js/run/draft.js:45-58 makes all options tie when no one voted and uses seeded RNG for the winner.
- js/modes/ninetynine.js:22 creates a single “solo” player; :197 card callback sends run.vote('solo',i).
- js/ui.js:621 card click calls onPick. It does not hide the modal or resolve the vote directly. No explicit “selected vote” render is present here, so the outlined card in the screenshot may simply have been browser focus styling.
- js/modes/ninetynine.js:515-519 calls run.tick(dt) and updates the bar; :198-200 hides modal on powerTaken and toasts the name.
- js/main.js:586 gates mode99.update(dt) on playing AND notpaused. This uses rawdt, whereas :588 multiplies combat dt by game.speed. Thus draft counting is not3X just because combat speed is3X.
- js/ui.js:632-634 exposes a proportional bar, not numeric seconds.

Conclusion: timeout and automatic choice were expected source behavior. Our sampling/relay overhead could consume the ten-second budget. Pausing stops timeout, but selecting while paused leaves the draft unresolved until resume, because the only resolver waits on a tick blocked by pause. This matches the observed modal remaining and later “Sharp Edge taken” toast. It is not just an animation delay. In solo mode, immediate resolution or clear “choice saved; resume to continue” feedback would remove uncertainty. A numerical countdown and visible fallback policy could also improve discoverability.

Missing verification: pause before expiration then wait longer than10real seconds; choose while paused and inspect one subsequent update; choose just before/at timeout; no-vote deterministic fallback; speed1X/3X should have same draft duration; immediate feedback and whether changing a stored vote is intended. Core semantics are read, not tested here. Do not retroactively name the unseen wave6 choice; exact RNG history was not collected.

## 4. Controls and Warden counters

Evidence:
- js/ui.js:178-183 opening help teaches generic “Drag ... to move” and Spacepause; omits mouse-marquee/possession/patrol mechanics.
- js/modes/ninetynine.js:338-341 explicitly reserves left drag for friendly-unit marquee in99Planets and leaves right/middle drag for pan.
- js/modes/ninetynine.js:388-392 claims normal mouse left drag when notbuilding/possessed. This explains RunA's rectangle instead of pan. It is not evidence the drag transport failed.
- js/modes/ninetynine.js:457-464 checks a nearby ally within3.2 worldunits and enters possession BEFORE handing the click to the previous tower-click handler. The preceding comment says tower panel keeps its tap, but there is no selectedTower exclusion in this conditional. This is a source-supported candidate for accidental takeover near a tower; exact hit arbitration still needs runtime testing.
- js/ui.js:162-165 displays possession keys including Spacejump/Ppause/Esc release. js/ui.js:512-514 implements Spacepause only when notpossessed, Ppause in both contexts, Fspeed only unpossessed.
- js/modes/ninetynine.js:320-334 supports a selected Warden's right-click patrol within leash; this mechanic was not discovered in the blind run.
- js/ui.js:921-922 prints summoner garrison,respawn,leash, then :928-929 unconditionally prints t.damageDealt/t.kills.

Conclusion: strongest onboarding issue is mode-inappropriate drag instructions. Possession is implemented deliberately, and the changed pause key is deliberate, but the entry gesture was not taught in the displayed opening help. A distinct unit affordance or specific possession action could avoid accidental takeover. Warden0/0 remains an attribution question; this bounded source set does not establish whether allies credit homeTower counters. Do not call Warden broken or harmless from this evidence.

Missing verification: leftdrag selection/rightdrag pan and click threshold; tower/ally overlap selection priority; possession entry while towerpanel open; Ppause in bothmodes; patrol effectiveness and rejection message; attribution of one controlled garrison hit/kill to its parent Warden; displayed statistics after soldier death/respawn/sell. None executed in this retrospective.

## Reporting boundary

The substantive runtime result remains blind natural defeat onwave11/15,330kills,6195score, no planet victory or boss reached. Source findings refine classification; they do not expand gameplay coverage. Frozen files were not modified. No code changes or test runs were made. Repository policy says camera defaults were owner-playtested and should not be changed without asking (CLAUDE.md camera invariant); these notes recommend clarity and targeted verification, not unapproved retuning.
