# Blind run A — frozen transport-limited record

Frozen 2026-09-05 approximately 21:17 UTC. Tester Astra subagent. URL https://majieddd.github.io/worldheart/. No repository, source, network, internals, strategy material, or other tester notes accessed. Only visible UI, accessibility tree and ordinary browser input. This is not a campaign completion record.

## Environment and terminal state
Chrome extension browser 3, tab 271657963, session “🎮 Blind 99 Worlds”. Screenshots 1707×954. Mode visibly named “99 Planets”, ROGUELITE CAMPAIGN, “ROGUELITE · 15 WAVES · BOSS”. Seed 8980257. Opening HP20/gold450. Speed progressed 1X→2X→3X. Settings initially quality Auto, shake On; lens close83/orbit37, angles48/66, min height .04R, max .67R, pan100%, zoom10%, look100%. Used Reset camera feel (max became .47R); then zoom slider set100. No talents inspected or purchased.

Paused by Space during wave2/15, 14 remaining, 1 nest, HP20, gold135, score175, Worldheart LV1/5, sole placed Bolt MKII. One additional Bolt card costs150. First wave cleared. No world transition, defeat, victory or boss reached. Chrome tab marked handoff.

## Chronology (tool-session order)
1. Opening instructions say drag/WASD move, scroll/+− zoom, QE rotate, R reset, keys1–5 choose tower, click build, U upgrade, X sell, Space pause, F speed. Selected 99 Planets and Begin the defense. Short delay before title overlay disappeared.
2. Wave1/15 with 15s countdown. Paused. R reset exposed enormous central ridge obscuring ground/core. Scroll-down two pages caused little immediate visible movement. Tool rejected key name 'minus'; this is a tool limitation, not game bug.
3. Press1 and clicked apparent open ground near glowing crystal (801,598); rejected with “Beyond the frontier. Survive a wave to push it out.” Placement guidance: “Click open ground to build. Every breach must keep a path to the heart.” This feedback was useful. Successful click inside luminous frontier (710,306) spent150.
4. Card disappeared; text became “Hand spent. This wave pays a power; the next pays a tower.” Selecting placed Bolt showed MKI, Damage11.7, Rate4.6/s, Range8.1, dealt0/kills0, Upgrade120/Sell+105. Upgraded to MKII: damage19.5, rate5.2/s, range8.8, sell189. Gold180. Upgrade disabled “Capped: raise the Worldheart”; HUD simultaneously said LV0 “tier cap MK III”.
5. Resumed, called wave (+26), gold206. Wave1 “SKITTERERS INCOMING”,7 remaining. Tried drag840,320→810,640; screenshot showed narrow rectangular selection rather than substantial camera motion. W,W,W,Q also little motion. Tool's discrete keypress may be inadequate for held movement; do not call game broken from this.
6. Settings inspected/reset as above. Adjusted zoom. Combat moved remarkably slowly across calls and 15–20s real waits, and screenshots often showed previous UI state while AX already changed. Hypothesis: background browser throttling/transport, not proven game performance defect. At3X first wave eventually killed enemies; no health loss.
7. At gold266 bought Worldheart upgrade B for250. HUD now LV1 “tier cap MK 4”; toast says “Worldheart raised to level 1: towers may reach mark 3”. This strengthens tier-label mismatch independently of the MKII disabled state.
8. R then scroll down8 eventually yielded a readable overview; terrain and luminous boundary are attractive and location becomes clearer. Wave1 cleared to wave2/15, HP20, gold119, score175,1 nest. New Bolt150 card appeared. No power-choice overlay observed. Called wave2 for+16 and paused at gold135; wave banner “WINGS ON THE HORIZON”.
9. Tried visible IAB browser for fresh run: tool says “IAB visibility is not supported in a subagent thread”. Parent-created IAB browser1/tab1 could not be accessed (“Tab not found”). Parent offers blind UI relay for next run, with tester making decisions from raw UI only.

## Findings
- A1, medium severity/high confidence visible mismatch: Heart tier cap one mark higher than tower/upgrade toast. Repro LV0 place Bolt→upgrade once→MKII disabled, HUD MKIII; upgrade Heart to1→HUD MK4 vs toast mark3. Actual intended cap unknown.
- A2, usability/medium confidence: close starting/reset camera makes huge ridge obscure much of relevant ground. Crystal outside initial frontier was mistaken for core; first placement failed. Zoom out resolves overview eventually. Defaults and transport may contribute; no claim all players see identical framing.
- A3, low-confidence question: spent-hand text predicts power reward but wave1 transition showed Bolt card without observed choice. Could have missed transient UI due transport; verify separately, not confirmed bug.
- A4, tooling blocker/high confidence: extremely slow visible advancement and one-interaction screenshot latency impaired normal pacing. No framerate measured; no causal claim against game. Visible IAB not available to subagent.

## Positives and coverage
Clear build rejection reason, costs/stats accessible, pause and speed work, successful placement/upgrades/early-call reward, readable frontier after zoom-out, attractive low-poly planet and bright tower combat feedback. Covered title, campaign selection, first wave complete, second wave start, Bolt building/upgrading, Heart upgrade, settings reset/zoom, camera attempts, pause/speed. Did not test boss, later rewards, selling, talents, other modes, saving, campaign progression or all99 worlds.

## Evidence
Screenshots are embedded in this subagent tool transcript: “Read game opening screen”; “Inspect placed tower”; “Raise Worldheart with earned gold” AX exact toast; “Observe combat progress at 3X”; “Check first reward availability”; final “Pause first attempt at transport boundary”. No standalone screenshot file was written; preserve transcript as session evidence. All factual findings above are frozen before any code inspection.
