# WORLDHEART — frozen blind playtest

**Blind record frozen: 2026-09-05 21:36 UTC.** Astra tester, delegated specifically to play with no prior game knowledge. No repository, source, game internals, browser logs, network inspection, strategy docs, or other tester interpretations were read. All gameplay decisions came from visible game UI and screenshots. No cheats, state injection, debug actions or console-assisted gameplay.

## Result and scope

Run A: Chrome transport-limited opening attempt, cleared wave1 and paused during wave2/15, HP20. Run B: fresh visible in-app-browser attempt through a parent-operated UI relay, **natural defeat on wave11/15**, 330 kills, score6,195. **No planet completed; no world transition or boss reached.** Do not describe the result as clearing11 waves: terminal screen labels11 WAVES but also says FELL ON WAVE11. Reached11, apparently cleared10.

Terminal exact text: THE HEART FADES / FELL ON WAVE 11 / 11 WAVES / 330 KILLS / 6,195 SCORE / Highest damage: Bolt Sentinel with 17,271. Buttons Same world, New world. HUD HP0, gold483, wave11/15,46remaining,3nests, HeartLV2/5, advertised capMK5, frontier+3rings(5held), upgrade700.

Run B is an informed fresh attempt using only Run A UI lessons (placing within luminous frontier, upgrading Bolt and zooming out). Run A did not end in defeat. Run B was not retried after its late-run defeat; parent explicitly asked to freeze at natural defeat. No claim of beating99 worlds, beating one planet, or completing all mode coverage.

## Method and environment

URL https://majieddd.github.io/worldheart/; requested99 Worlds corresponds to visible menu **99 Planets**. Menu: ROGUELITE CAMPAIGN, ROGUELITE · 15 WAVES · BOSS, “One tower. Fifteen waves. Raise the Worldheart to hold more ground, and clear the nests beyond it.”

Run A details preserved separately in run-a-frozen.md. Chrome extension browser3/tab271657963, screenshots1707×954, seed8980257, qualityAuto/shakeOn, camera settings recorded there. Slow sim progression and screenshot latency prompted surface switch. Subagent could not create visible IAB (“IAB visibility is not supported in a subagent thread”) or access parent IAB (“Tab not found”). These are tooling limits.

Run B parent-created visible IAB browser1/tab1, screenshots1786×1272. Parent relayed raw AX/screenshot files and performed this tester's requested normal UI actions. Parent did not provide source, strategy or interpretations. Tester chose placements/upgrades/powers and contingencies. Seed not inspected in B. No talents purchased. Speed briefly3X at opening; reduced1X for all later combat. Frequent pause between decisions. No deliberate camera settings changes in B; R and scroll-down8 at opening. No other modes played.

Relay timing means a request to pause at an observed threshold sometimes executed after additional simulation time. Parent sampled about5s initially and ~2s later, but tool/model overhead adds time. Timed rewards occasionally expired between observations. This materially limits comparisons to a continuous-input human playtest and precise cause-of-death diagnosis. No frame-rate measurements were taken. Screenshots and AX can be temporally offset; use paired observations and clear deltas rather than assume exact simultaneity.

## Contemporaneous sequence — Run B

1. Selected99Planets, Begin, Space paused. HP20 gold450. R+scroll-down8 to widen view. View initially close; zoom continued easing dramatically once resumed.
2. Placed first Bolt(1090,674), spent150, selected/upgraded120 toMKII. HeartLV0 HUDcapMKIII while actual MKII tower upgrade disabled Capped: raise the Worldheart. Called+28, resumed3X. First wave cleared withHP20.
3. Next observations jumped from wave2 14remaining/gold371 to wave2 1remaining/gold543/score315 with power modal. Chose Sharp Edge(+5%critical chance). Bought HeartB250→LV1/gold293. HUDcapMK4; toast “Worldheart raised to level 1: towers may reach mark 3”. Modal stayed while paused; brief resume dismissed, toast Sharp Edge taken/WARDEN unlocked. Switched1X. Pausedwave3 countdown4s.
4. Placed second Bolt(827,555) near crystal, upgraded120; gold23. Wave3→4 lostHP20→17, gold250,score580. New Warden220 card. Placed Warden(946,350), gold30. MKI garrison2,respawn7s,leash7,range7,damage0/kills0; upgrade176 unaffordable.
5. Wave4 HP15→11→9; held-wave reward+106gold/+18coins appeared with6remaining/2nests; pause occurredHP7,gold282,score855,2remaining, power choices SharpEdge/Flywheel/CryoField. Chose Flywheel(towers fire18%faster). Brief resume then pause dismissed modal. CRYO unlocked. Wave5 countdown11s.
6. Selected near-core/north Bolt MKII:17.3damage,6.1rate,8.8range,dealt1618,kills16. Upgrade195→MKIII,27.6damage,7.1rate,9.6range,gold87. Wave5 fellHP7→3; atwave6 pausedHP3,gold360,score1145,Bolt150card.
7. Emergency Bolt(896,291) southwest of crystal guarding visible exposed approach; upgrade120 toMKII, gold90. Wave6 heldHP3. Power seen atgold490: SharpEdge/HardenedHeart(+2lives)/TwinRails(+20%damage), but gone by pause before explicit choice. Unknown selection. Wave7 gold520,score1735,HP3.
8. Upgraded emergency Bolt195→MKIII (prior1439damage/18kills), then first Warden176→MKII,garrison3,respawn6s,leash9,range9; its panel still0damage/0kills. Gold149. Heldwave7HP3, pausedwave8HP3,gold552,score2210,34remaining,3nests,Warden220card.
9. Camera had drifted away from core without deliberate camera input since prior placements. R paused did not visibly recenter; brief resume still away, HP3gold652. Placed Warden(1070,856) among visible approaching ground pack; upgraded176,gold256. Wave8 heldHP3; reward was not seen in samples. Pausedwave9HP3gold826score3255,34remaining,3nests.
10. Bought Heart450→LV2, gold376. HUDcapMK5/frontier+3rings; toast may reachmark4. Nest count subsequently2. Tried selecting previous Warden coordinate but instead entered direct-control view of a Warden unit. Visible new controls: WASD move, Shift sprint, LMB strike, Space jump,1-6build,Scroll view,P pause,H dismiss,Esc release. No direct combat input made. Esc gave Control released and overhead view returned, now core plainly visible. This was an accidental discovery.
11. One attempt selecting northBolt(967,566) hit no tower; fresh screenshot showed shifted framing. New base(984,615) selected MKIII, prior7566damage/81kills. Upgrade293→MK4,52.5damage,range11.1,gold83. Wave9 heldHP3. Wave10 pausedHP3gold810score4370,45remaining,2nests,Warden220card.
12. Placed Warden(997,470) north of upgraded Bolt; upgrades176+286→MKIII,garrison5,respawn5s,leash11,gold128. Wave10 fellHP3→1. Nextwave11 screenshot stillHP1. Toast Mending taken / HELIOS unlocked appeared without tester selecting it; description/effect unknown. Reward missed despite shorter sampling. Wave11 pausedHP1gold1030score5770.
13. Spent on concentrated defenses: southwestBolt MKIII→IV293; eastBolt MKII→III195→IV293; gold249. Resumed1X. Nextsample showedHP0, THE HEART FADES, fellwave11. Finalgold483,score6195,330kills.

The tester's recovery strategy was to cover the exposed southwest path, raise Bolt marks close to the crystal, then use Wardens to hold approaching ground units in firing range. This recovered fromHP3 atwave5 throughwave9. It was insufficient bywave11. Loss alone is not evidence of a balance bug, particularly given initial misplacement and timed input limitations.

## Findings, confidence and reproduction

### B1 — Tier cap text disagrees with actual upgrade cap (medium severity, high confidence)

Repro: enter99Planets; placeBolt150; upgrade once120. TowerMKII is capped while HeartLV0 panel advertises tiercapMKIII. BuyHeart250; panel advertisesMK4 while toast says towers may reachmark3. BuyHeart450; panel advertisesMK5 while toast saysmark4. Reproduced across both surfaces and multiple Heart levels. Misleads spending/progression planning. Actual intended cap is unknown without later implementation audit.

Evidence: relay03-cap.png,05-heart.png,11-mkiii.png, parent AX for B250/B450. Run A independently observed first two levels.

### B2 — Paused camera/reward behavior is hard to interpret (usability, medium confidence; cause unresolved)

R/zoom while paused yielded little immediate camera movement; zoom later changed considerably upon resuming. Power choice visibly outlined after click and stayed on screen while paused, then dismissed after brief resume. Because pause is useful for strategy/readability, delayed visual confirmation makes a player unsure whether inputs applied. Caveat: some camera movement also occurred across paused screenshot captures, so do not assert all camera interpolation is blocked by pause. Could include UI transport latency/inertia.

Repro for choice: pause with CHOOSE A POWER visible, chooseSharpEdge, observe selection outline/modal persisting, resume then it disappears/Sharp Edge taken. Evidence04-wave2.png,06-after-choice.png,07-ground.png. Camera evidence01-opening,02-zoom,07-ground and15-reset/16-reset-resumed.

### B3 — Timed powers can resolve before deliberate choice (usability, high confidence occurrence, unknown timing/design)

Atwave6 HardenedHeart+2lives was offered whileHP3, but modal disappeared before next pause/select action. Later toast Mending taken appeared with no tester choice. Reward cards have a draining-looking horizontal bar but no numeric timer observed. Choice timeout duration and fallback policy were not measured; no claim which power auto-selected atwave6. Continuous human clicking may fare better, but relay delays demonstrate timing/accessibility friction and undermine planning. Evidence10-reward shows bar;13-wave6-reward-ax.txt records offered power set;22-wave11/AX and relay messages record Mending toast. Need verify pause semantics and timeout policy during later audit.

### B4 — Direct-control mode discoverability and key switching (usability, medium severity/confidence)

A click intended to select Warden tower instead selected a nearby unit and entered direct control. Opening instructions taught Space=pause; direct-controlHUD teaches Space=jump and P=pause. Escape instruction enabled recovery. No initial explanation of unit possession had been noticed. This is a surprising mode switch rather than proof of bug. Evidence18-possession.png and19-release.png. Repro requires clicking visible Warden garrison, not tower; exact accidentally hit unit coordinate1070,856 at that moment.

### B5 — Warden panel did not report contribution (question, low confidence defect)

First Warden remainedDealt0/Kills0 after multiple waves and beforeMKII upgrade. It spawns garrison units, so displayed stats might intentionally omit their damage. No direct attribution measured. It made effectiveness hard to assess. Do not label confirmed nonfiring bug. Evidence09-warden.png/AX plus upgrade relay atwave7.

### B6 — Camera position changes made tower targeting difficult (usability/tool interaction, cause uncertain)

View moved substantially with no intentional camera-pan commands during tower-click/upgrade/close bundles. Could be edge pan, selection focus, R/scroll easing, or input transport; not diagnosed. Atwave9 same-coordinate selection entered garrison possession; a later click hit no tower until fresh screenshot/base retarget. Need reproduce with continuous human cursor control before classifying as game defect. Screenshots14,15,16,18,19,20 show distinct states. Do not claim random camera bug.

### B7 — Opening framing/core identification (usability observation, medium confidence)

Large ridges and close framing obscured core/paths; initial A first placement near glowing crystal failed beyondfrontier. Luminous frontier and reasoned placement toast were useful once understood. B initially placed an eastward tower then lost health until concentrating coverage southwest. Different initial view/seed plus tester misunderstanding matter; this is onboarding friction, not proof map invalid.

## Positives

Attractive low-poly planetary terrain and bright combat effects. Costs, upgrade statistics and wave/health economy readable in accessible text. Clear rejected placement reason, successful pause/build while paused, early-call gold visible. Tight economy/card supply forced meaningful investment choices. The improvised southwest defense produced a measurable recovery, holdingHP3 several waves. Reward variety (crit,fire rate,health,economy,slow) and Warden garrisons suggest distinct tactics. Defeat screen clearly states wave,kills,score and highest-damage tower, with same/new-world options.

## Coverage gaps

No victory,world transition,boss,wave12–15,99-world traversal,save/persistence,other modes,talents,selling,manual nest targeting,Helios/Cryo building,manual unit combat,unit dismissal or meaningful first-person movement. No sound assessment, responsive/mobile test or performance measurement. Observed nest counts decreased3→2 around Heart expansion/combat, but no causal inference or manual clearing verified. No raw source read after freeze.

## Evidence index

All paths under C:/Users/Majied LaFleur/Documents/GPTProjects/worldheart-qa-evidence/2026-09-05/relay/. Parent saved screenshot/AX pairs for named checkpoints; some AX files are diffs rather than complete snapshots.

- 00-title.png: campaign entry.
- 01-opening.png,02-zoom.png: paused setup/camera.
- 03-cap.png,05-heart.png: cap mismatch.
- 04-wave2.png,06-after-choice.png,07-ground.png: first power/pause/dismissal.
- 08-wave4.png,09-warden.png,10-reward.png: health decline,garrison,Flywheel.
- 11-mkiii.png,12-emergency.png,13-wave6-reward.png: recovery setup/timed choice context.
- 14-wave8.png,15-reset.png,16-reset-resumed.png,17-wave9.png: middle run/camera.
- 18-possession.png,19-release.png,20-tower-attempt.png: accidental possession/selection.
- 21-wave10.png,22-wave11.png: late defense.
- **23-defeat.png**: authoritative natural terminal result.

RunA standalone file run-a-frozen.md retains its session-only screenshot references. This entire blind record is now frozen and should be kept separate from later source-informed validation/corrections.
